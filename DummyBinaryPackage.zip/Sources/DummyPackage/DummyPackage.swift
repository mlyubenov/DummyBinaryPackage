public struct DummyPackage {
    public private(set) var text = "Hello, World!"

    public init() {
    }

	public static func dummyFunc() {
		print("Demo Dummy Package")
	}
}
